/*QUnit.test("Тест CalculateRating(rating, string)", function( assert ){
  var result = CalculateRating(100, '2 - 0');
  assert.equal(result, 200, "Победа 1 команды со счетом 2 0");
  //equal(CalculateRating(100, '2 - 0'), 200, 'Победа 1 команды со счетом 2 0');
});*/
/*import { CalculateRating } from './betsSelector.js';

QUnit.test("CalculateRating(rating, string)", function( assert ){
  assert.equal(CalculateRating(100, '2 - 0'), 200, "Победа 1 команды со счетом 2 0");
});*/
